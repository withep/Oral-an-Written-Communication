let quizData = {};
let currentLevel = null;
let currentQuestionIndex = 0;
let score = 0;

// JSON verisini yükle
async function loadQuestions() {
    const response = await fetch('questions_demo.json');
    quizData = await response.json();
}

function showScreen(screenId) {
    document.querySelectorAll('.app-container > div').forEach(div => div.style.display = 'none');
    document.getElementById(screenId).style.display = 'block';
}

function pickClass(level) {
    currentLevel = level;
    showScreen('screen-difficulty');
}

function startQuiz(difficulty) {
    // Burada difficulty'ye göre mantık kurabilirsiniz, şimdilik level 1 ile başlıyoruz
    currentQuestionIndex = 0;
    score = 0;
    updateScore();
    showScreen('screen-quiz');
    showQuestion();
}

function showQuestion() {
    const questions = quizData[currentLevel];
    if (currentQuestionIndex >= questions.length) {
        alert("Bölümü tamamladın! Skorun: " + score);
        showScreen('screen-class');
        return;
    }

    const q = questions[currentQuestionIndex];
    document.getElementById('question-box').innerText = q.question;
    
    const optionsBox = document.getElementById('options-box');
    optionsBox.innerHTML = '';
    
    for (const [key, value] of Object.entries(q.options)) {
        const btn = document.createElement('button');
        btn.innerText = `${key}) ${value}`;
        btn.onclick = () => checkAnswer(key);
        optionsBox.appendChild(btn);
    }
}

function checkAnswer(choice) {
    const correct = quizData[currentLevel][currentQuestionIndex].answer;
    if (choice === correct) {
        score += 10;
        alert("Doğru!");
    } else {
        alert("Yanlış! Doğru cevap: " + correct);
    }
    currentQuestionIndex++;
    updateScore();
    showQuestion();
}

function updateScore() {
    document.getElementById('score-text').innerText = `Skor: ${score}`;
}

function changeTheme(theme) {
    const root = document.documentElement;
    
    if (theme === 'purple') {
        root.style.setProperty('--primary-color', '#6200ea');
        root.style.setProperty('--bg-color', '#1e1e1e');
    } else if (theme === 'blue') {
        root.style.setProperty('--primary-color', '#2196f3');
        root.style.setProperty('--bg-color', '#0d47a1');
    } else if (theme === 'dark') {
        root.style.setProperty('--primary-color', '#333333');
        root.style.setProperty('--bg-color', '#121212');
    }
}
loadQuestions();